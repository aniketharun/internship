import React from 'react';

const Sidebar = () => {
    return (
        <div className="d-flex flex-column flex-shrink-0 p-3 bg-white" style={{ width: '250px', height: '100vh', borderRight: '1px solid #eee' }}>
            <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
                <span className="fs-4 fw-bold p-2 text-white rounded me-2" style={{ backgroundColor: '#6f42c1' }}>C</span>
                <span className="fs-5 fw-bold">Company</span>
            </a>
            <br />
            <ul className="nav nav-pills flex-column mb-auto">
                <li className="nav-item">
                    <a href="#" className="nav-link link-dark" aria-current="page">
                        <i className="bi bi-house-door me-2"></i>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="#" className="nav-link link-dark">
                        <i className="bi bi-inbox me-2"></i>
                        Intake
                        <span className="badge bg-purple ms-auto float-end" style={{ backgroundColor: '#6f42c1' }}>2</span>
                    </a>
                </li>
                <li>
                    <a href="#" className="nav-link link-dark">
                        <i className="bi bi-briefcase me-2"></i>
                        Matters
                    </a>
                </li>
                <li>
                    <div className="text-secondary small fw-bold mt-3 mb-2 px-3">FINANCE</div>
                </li>
                <li>
                    <a href="#" className="nav-link active" style={{ backgroundColor: '#f8f0ff', color: '#6f42c1' }}>
                        <i className="bi bi-currency-dollar me-2"></i>
                        Billing
                    </a>
                </li>
                <li>
                    <a href="#" className="nav-link link-dark">
                        <i className="bi bi-bar-chart me-2"></i>
                        Report
                    </a>
                </li>
                <li>
                    <a href="#" className="nav-link link-dark">
                        <i className="bi bi-calendar3 me-2"></i>
                        Calendar
                    </a>
                </li>
            </ul>
            <hr />
            <ul className="nav nav-pills flex-column">
                <li>
                    <a href="#" className="nav-link link-dark">
                        <i className="bi bi-gear me-2"></i>
                        Settings
                    </a>
                </li>
                <li>
                    <a href="#" className="nav-link link-dark">
                        <i className="bi bi-question-circle me-2"></i>
                        Help & Support
                    </a>
                </li>
            </ul>
            <hr />
            <div className="dropdown">
                <a href="#" className="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
                    <div className="profile-pic-container bg-secondary bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center me-2" style={{ width: '32px', height: '32px' }}>
                        <i className="bi bi-person-fill text-secondary"></i>
                    </div>
                    <div>
                        <strong>John Davis</strong>
                        <div className="text-muted small">Admin</div>
                    </div>
                </a>
                <ul className="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">
                    <li><a className="dropdown-item" href="#">Profile</a></li>
                    <li><hr className="dropdown-divider" /></li>
                    <li><a className="dropdown-item" href="#">Sign out</a></li>
                </ul>
            </div>
        </div>
    );
};

export default Sidebar;
